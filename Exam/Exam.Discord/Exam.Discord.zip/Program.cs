﻿using System;

namespace Exam.Discord
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine( "test");
        }
    }
}
