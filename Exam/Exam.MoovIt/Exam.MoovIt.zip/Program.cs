﻿using System;

namespace Exam.MoovIt
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("test");
        }
    }
}